
## 파일 형식

```markdown
---
date: YYYY-MM-DD
location: office  # home 또는 office 또는 창고 또는 저장되어진 위치, 앞으로 저장해야할 위치 정보
time_in: HH:MM
time_out: HH:MM
energy: 7         # 1-10
mood: 8           # 1-10
---

## 오늘 한 일

## 잘 된 것

## 아쉬운 것 / 배운 것

## 내일 할 것
